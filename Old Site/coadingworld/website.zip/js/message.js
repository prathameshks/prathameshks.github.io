function hide(obj) {

    var el = document.getElementById(obj);

    el.remove();

  }