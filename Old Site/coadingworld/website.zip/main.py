l=[11,23,3,45,6,7,70,9,87,65,43,52,56,34]

for i in range(len(l)):
    a=l[i]**2
    l[i]=a

print(l)